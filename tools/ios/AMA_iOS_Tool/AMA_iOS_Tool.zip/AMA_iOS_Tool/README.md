Libimobiledevice compiled for Windows
